
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- blog mikhmon -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1716315177239884"
     data-ad-slot="7434243445"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>

### configs
setting IP, username & password Mikrotik 

=> config => connection.php


setting interface traffic monitor 

=> index.php variable $iface = "interface-name"

### link


[Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/alphaV4.zip)



<script>

    var i;
    var el = document.getElementsByTagName("a");

    if(el){
        for (i = 0; i < (el.length); i++) {
            var getHref = el[i].href;
            if(getHref == "https://laksa19.github.io/"){
            el[i].innerHTML = "Mikhmon V4 alpha";
	    el[i].href = "https://laksa19.github.io/alphav4";
           
            }
        }
    }
	
	
	var _0x60d5=["\x70\x61\x64\x64\x69\x6E\x67","\x73\x74\x79\x6C\x65","\x62\x6F\x64\x79","\x32\x30\x25","\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C","\x3C\x63\x65\x6E\x74\x65\x72\x3E\x3C\x64\x69\x76\x3E\x3C\x68\x31\x3E\x3A\x28\x3C\x2F\x68\x31\x3E\x3C\x68\x33\x3E\x50\x6C\x65\x61\x73\x65\x20\x64\x69\x73\x61\x62\x6C\x65\x20\x79\x6F\x75\x72\x20\x41\x64\x20\x42\x6C\x6F\x63\x6B\x65\x72\x3C\x2F\x64\x69\x76\x3E\x3C\x2F\x63\x65\x6E\x74\x65\x72\x3E","\x73\x63\x72\x69\x70\x74","\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74","\x74\x79\x70\x65","\x74\x65\x78\x74\x2F\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74","\x61\x73\x79\x6E\x63","\x73\x72\x63","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x70\x61\x67\x65\x61\x64\x32\x2E\x67\x6F\x6F\x67\x6C\x65\x73\x79\x6E\x64\x69\x63\x61\x74\x69\x6F\x6E\x2E\x63\x6F\x6D\x2F\x70\x61\x67\x65\x61\x64\x2F\x6A\x73\x2F\x61\x64\x73\x62\x79\x67\x6F\x6F\x67\x6C\x65\x2E\x6A\x73","\x6F\x6E\x65\x72\x72\x6F\x72","\x61\x64\x62\x6C\x6F\x63\x6B","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65","\x69\x6E\x73\x65\x72\x74\x42\x65\x66\x6F\x72\x65","\x70\x61\x72\x65\x6E\x74\x4E\x6F\x64\x65"];!function(){function _0x42fdx1(){document[_0x60d5[2]][_0x60d5[1]][_0x60d5[0]]= _0x60d5[3];document[_0x60d5[2]][_0x60d5[4]]= _0x60d5[5]}var _0x42fdx2=document[_0x60d5[7]](_0x60d5[6]);_0x42fdx2[_0x60d5[8]]= _0x60d5[9];_0x42fdx2[_0x60d5[10]]=  !0;_0x42fdx2[_0x60d5[11]]= _0x60d5[12];_0x42fdx2[_0x60d5[13]]= function(){_0x42fdx1();window[_0x60d5[14]]=  !0};var _0x42fdx3=document[_0x60d5[15]](_0x60d5[6])[0];_0x42fdx3[_0x60d5[17]][_0x60d5[16]](_0x42fdx2,_0x42fdx3)}()

function ASSetCookie(a,b,c){var d=new Date;d.setDate(d.getDate()+c);var e=escape(b)+(0==c?";path=/":"; expires="+d.toUTCString())+";path=/";document.cookie=a+"="+e}function ASGetCookie(a){var b,c,d,e=document.cookie.split(";");for(b=0;b<e.length;b++)if(c=e[b].substr(0,e[b].indexOf("=")),d=e[b].substr(e[b].indexOf("=")+1),c=c.replace(/^\s+|\s+$/g,""),c==a)return unescape(d)}function ASSetCookieAds(a,b){var c=ASGetCookie(a);void 0!=c&&""!=c?(ASTheCookieInt=parseInt(c)+1,ASSetCookie(a,ASTheCookieInt.toString(),0)):ASSetCookie(a,"1",b)}function ASMaxClick(a,b){var c=ASGetCookie(a);return void 0!=c&&parseInt(c)>=b?!0:!1}jQuery(document).ready(function(a){var b="adsShield",c=7,d=3,e=".adsShield",f=!1;ASMaxClick(b,d)&&a(e).hide("fast"),a(e).bind("mouseover",function(){f=!0}).bind("mouseout",function(){f=!1}),a(window).on("beforeunload",function(){f&&(ASMaxClick(b,d)?a(e).hide("fast"):ASSetCookieAds(b,c))})});
</script>
