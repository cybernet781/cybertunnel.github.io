### Mikhmon Blog

#### Set last Date & Time

![](./img/setdatetime-s.png)

Solusi untuk pengaturan jam dan tanggal agar tidak kembali ke tanggal default `jan/01/1970 00:00:00` setelah RB reboot atau listrik padam. [*Baca selengkapnya...*](./?blog/set-date-time "Read more...")

#### User Hotspot terhapus setelah reboot. 

![](./img/usersmissing-s.png)

Kenapa user hotspot yang sudah saya generate tiba-tiba hilang setelah reboot atau mati listrik? [*Baca selengkapnya...*](./?blog/hotspot-users-missing "Read more...")
