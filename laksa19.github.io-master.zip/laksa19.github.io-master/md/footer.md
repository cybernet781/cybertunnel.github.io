----
&copy; Laksamadi Guko 2017 - 2020