### Jasa Setting MikroTik
Untuk yang membutuhkan jasa setting MikroTik, silakan hubungi penyedia jasa berikut.
>Semua penyedia jasa yang tercantum di sini adalah penyedia jasa mandiri bukan dari Mikhmon.

#### Jasa Setting Mikrotik PropesionaL
- WA : [Klik di sini](bit.ly/2MkCETR)
- Website : [zainalrinaldi90](https://www.facebook.com/zainalrinaldi90)
- Estimasi biaya : `Rp300.000` - `Rp1.000.000`
- Syarat dan Ketentuan : 
  - Menyiapkan gambar topologi sebelum melakukan Remot , & Prosedur Tranfer Dahulu Baru Remot.
  - Biaya Tergantung Request Dan Topologi Jaringan Anda.
---
#### Setting Router MikroTik, Inatallasi Warnet & Game Online Mode Diskless
- WA : [Klik di sini](https://wa.me/62811511848)
- Website : [Jaringanbanjar.net](http://jaringanbanjar.net) ( coming soon )
- Estimasi biaya : `Rp300.000` - `Rp5.000.000`
- Syarat dan ketentuan : di utamakan Daerah Kalimantan Selatan , Luar Kalimantan Silahkan PM
---
#### Inikaryaku / Riyadhul Jannah 
>(setting MikroTik, OpenWrt, Flash eeprom, Loadbalance, Unlock Cisco ke standalone dll..
- WA : [Klik di sini](https://wa.me/6282126666957)
- Website : -
- Estimasi biaya : `Rp200.000` - `Rp2.000.000`
- Syarat dan Ketentuan :
  - Harga hanya jasa setting, peralatan MikroTik Access Point dan lainnya sudah ada terutama akses internet.
  - Untuk yang pakai Cisco harga unlock Cisco di luar biaya setting MikroTik.
  - Luar jangkauan via remote, kecuali flash chip eeprom & unlock Cisco tidak menerima via remote.
---
#### Shinobie Palembang
- WA : [Klik di sini](https://wa.me/6281272176746)
- Website : [shinobie.com](http://shinobie.com)
- Estimasi biaya : `disesuaikan dengan kebutuhan`
- Syarat dan Ketentuan : Team Viewer, Ultra Viewer, AnyDesk
---
<div>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- ads3 -->
	<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-1716315177239884" data-ad-slot="4095402072"
	 data-ad-format="auto" data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>

#### Benny
- WA : [Klik di sini](https://wa.me/6282175936659)
- Website : [indorouting.wordpress.com](https://indorouting.wordpress.com)
- Estimasi biaya : `Rp200.000`keatas.
- Syarat dan Ketentuan : 
  `Game` `Ping` `Sosmed` `Youtube` `Situs streaming` `Browsing` `Download`
  - Metode limitasi : Queue Tree
    - Pemisahan di atas berlaku untuk penggunaan 1 line ISP, apabila ada load balance didalamnya maka harga menyesuaikan dengan teknik load balance yang di pakai.
    - Garansi setting selamanya (hanya berlaku pada perbaikan, penambahan fitur akan dikenakan biaya).
---    
#### Purwanto (Setting Mikrotik se-Indonesia)
- WA : [Klik di sini](https://wa.me/6282233483221)
- Website: [Purwanto](https://fb.com/botdrex)
- Estimasi biaya : Sesuai kebutuhan, mulai `Rp50.000` sampai `Rp5.000.000`
- Syarat dan ketentuan : Kirim gambar topologi.    
---
#### BuanaNet - Jasa Setting Mikrotik 100% Terpercayaa
- WA : [Klik di sini](https://wa.me/6281328298448)
- Website : [BuanaNet](https://www.facebook.com/buananetmikrotik)
- Estimasi biaya : `dinamis`
- Syarat dan Ketentuan :
  - Ketentuan umum silahkan konsultasi kan topologi nya dan request.
     
     PERATURAN GARANSI DAN MAINTENANCE:
    1. Garansi dan Support berlaku 1 bulan, termasuk cek jaringan dan permasalahan pada settingan Mikrotik.
    2. Garansi dan Support tidak berlaku jika terjadi kerusakan dan penggantian perangkat Mikrotik, kecuali ada perjanjian diawal.
    3. Garansi dan Support tidak berlaku jika melakukan perubahan sendiri setingan Mikrotik.
    4. Garansi dan Support secara gratis akan kami berikan untuk sekedar cek permasalahan jaringan seperti Browsing lemot dan Game Lag (*dengan catatan tidak ada kewajiban kami harus saat itu juga melakukan pengecekan*)
    5. Garansi dan Support diluar masa garansi akan dikenakan biaya tambahan sesuai dengan tingkat kerumitan, terutama jika ada penambahan dan perbaikan script misalkan pada Firewall, Queue dan Routing.
    6. Garansi dan Support diluar masa garansi jika ada penambahan atau pengurangan Line Internet Service Provider (ISP) akan dikenakan biaya tambahan.
    7. Untuk menghindari kesalahan atau pembobolan atau duplikasi script, hanya kami yang memegang hak akses "Full" Admin Router, selain itu client hanya bisa akses "Read/Write".
    8. Jika suatu saat ada permintaan hak akses "Full" Admin Router untuk keperluan khusus seperti reset, akses ftp dan lainnya tetap akan kami berikan dengan syarat kami tidak mensupport lagi setelahnya, terkecuali hak full akses di kembalikan lagi ke Read/Write maka akan tetap kami support.
   Pastikan jangan salah memilih jasa setting, karena beda setingan akan berbeda pula hasilnya.
---
<div>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- ads3 -->
	<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-1716315177239884" data-ad-slot="4095402072"
	 data-ad-format="auto" data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>

#### Jak Net
- WA : [Klik di sini](https://wa.me/6283129199615)
- Website : [JakNet](https://www.facebook.com/Jaknet22)
- Estimasi biaya : `Rp200.000` - `Rp2.000.000`
- Syarat dan Ketentuan : `Games` `Latency` `Sosmed` `Youtube` `Streaming` `Browsing` `Download`
---
#### Jasa Reset MikroTik, Autopilot MikroTik
>LB 2 wireles autopilot openwrt...
- WA : [Klik di sini](https://wa.me/628112615677)
- Website : [idun.sibolank]( https://www.facebook.com/idun.sibolank)
- Estimasi biaya : Mulai dari `Rp100.000`
- Syarat dan Ketentuan : Kirim gambar topologi, Desain Loginpage, Garansi 1 Bulan, Ganti MikroTik, garansi hilang.
---
#### Barkatech Networking
>Utk berlangganan tiap bulan, tanpa ribet, kami bisa jadi assist anda, PM utk detail
Siap membangunkan infrastruktur baru, untuk skala UKM kebawah, agar memiliki Jasa penyedia akses internet hotspot.
Generate Voucher dan pencetakan user baru di hotspot tanpa biaya.
- Produk
  - SETUP MIKROTIK INCLUDE STANDARD HOTSPOT 150
  - SETUP HOTSPOT+PPPOE FULL PLUS TEMPLATE KEREN 200
  - LOADBALANCE 250
  - PISAH JALUR GAME ONLINE, UMUM, YOUTUBE 250

- WA : [Klik di sini](https://wa.me/6282271100232) (WA Only)
- Website : - `Instagram  toko_barka` `Facebook  Mubarok Ahmad` `FB Page  barka_tech`
- Estimasi biaya : `Rp150.000` - `Rp1.000.000`
- Syarat dan ketentuan : 
  - Akses hanya kami berikan pada klien kami, sebatas Read and Write saja.
  - Untuk akses Full, hanya pihak kamu yang memiliki akses.
  - Jika diketemukan; ingin mencari jasa lain, maka akan kami beri akses Full; dgn ketentuan bahwa telah terjadi putusnya kontrak kerja.
  - Belum termasuk setting AP, Klien Router.
---
#### Yuli Ismanto
- WS : [Klik di sini](https://wa.me/6281279995166)
- Website : [Yuli.Ismanto](https://www.facebook.com/Ajodowngrade)
- Estimasi biaya : `Rp100.000` - `5.000.000`
- Syarat & ketentuan : Menyiapkan/bersedia memberikan gambaran topologi dan yg pasti konsul gratis remote bayar.
---
