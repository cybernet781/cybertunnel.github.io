## Mikhmon V4 Beta 1

!Only for localhost

#### Ready
1. Dashboard
2. Hotspot
  - Users (add & remove user)
  - User Profile (remove profile)
  - Active (remove user)
  - Host
  - @global filter
3. Log 
4. Report (global filter & download CSV)
5. Template editor. New template format html

#### Dashboard

![MIKHMON V4B1](./img/mikhmonv4b1.png "MIKHMON V4B1")

#### Tutorial Youtube

[![](./assets/img/video.png) Video Panduan](https://youtu.be/LqIGkT4VvIo)
  

#### Download

[![Download Mikhmon V4 Beta1](./assets/img/download.png) Download Mikhmon V4 Beta1](https://drive.google.com/file/d/1Wxds4MNwdIASAGci6Ne5iLfHufmEoupd/view?usp=sharing)

[![Download VC15](./assets/img/download.png) Download VC15](https://www.microsoft.com/en-us/download/details.aspx?id=48145)
