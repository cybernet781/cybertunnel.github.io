### Template Voucher Mikhmon V3

Template Voucher Mikhmon
Mikhmon memiliki 3 jenis template voucher (Default, Thermal dan Small).
Default atau Small adalah template yang digunakan untuk print lebih dari satu voucher.
Thermal adalah template yang digunakan untuk print satu voucher (tujuan untuk printer thermal).


>Penting! Jangan langsung copy paste. Template ini perlu disesuaikan dengan kebutuhan masing-masing. Keterangan ada di template.

>Jika sudah yakin baru dimasukkan ke Mikhmon lewat menu Settings-> Template Editor.

----

#### Default Color by Price

![](./img/voucher/cbp.png) ![](./img/voucher/cbpup.png)

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/vdefaultcolorbyprice.txt)

#### Default Detail

![](./img/voucher/detail.png) ![](./img/voucher/detailup.png)

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/vdefaultdetail.txt) [![](./assets/img/download.png) Download BW](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/vdefaultdetailbw.txt)

<div>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- ads3 -->
	<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-1716315177239884" data-ad-slot="4095402072"
	 data-ad-format="auto" data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>

#### Default Elegan

![](./img/voucher/eleganqr.png) ![](./img/voucher/eleganupqr.png)

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/velegan.txt) [![](./assets/img/download.png) Download BW](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/veleganbw.txt)

#### Ala Kangdo

![](./img/voucher/alaKangdoVC.png) ![](./img/voucher/alaKangdoUP.png)

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/alaKangdo.txt) [![](./assets/img/download.png) Download BW](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/alaKangdoBW.txt)

#### Default Abu Shafa 1

![](./img/voucher/abuqr.png) ![](./img/voucher/abuupqr.png)

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/Abu_Shafa_1.txt)

<div>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- ads3 -->
	<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-1716315177239884" data-ad-slot="4095402072"
	 data-ad-format="auto" data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>

#### Default Abu Shafa Orange

![](./img/voucher/orangeqr.png) ![](./img/voucher/orangeupqr.png)

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/Orange.txt)

#### MKS Isber Nendi

![](./img/voucher/mks.jpg) 

[![](./assets/img/download.png) Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/voucher/mks.txt)


#### Template Voucher Pihak ke 3

[KevinNet](https://isbernendi.github.io/voucher.html)
