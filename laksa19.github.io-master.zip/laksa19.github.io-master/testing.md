<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- blog mikhmon -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1716315177239884"
     data-ad-slot="7434243445"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
### configs

```
copy config.php from Mikhmon V3 to Mikhmon alphaV4

Mikhmon V3

=> include => config.php

Mikhmon alphaV4

=> config => config.php


```

### ready
1. View
	1. Dashboard
	2. Hotspot
	3. Log
	4. Report
2. Print (default template)



### Dashboard Mikhmon V4
![mikhmon alpha v4](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/img/alphaV4.png)
### Download link

[Download](https://raw.githubusercontent.com/laksa19/laksa19.github.io/master/download/alphaV4.zip)

<script>

    var i;
    var el = document.getElementsByTagName("a");

    if(el){
        for (i = 0; i < (el.length); i++) {
            var getHref = el[i].href;
            if(getHref == "https://laksa19.github.io/"){
            el[i].innerHTML = "Mikhmon V4 alpha";
	    el[i].href = "https://laksa19.github.io/testing";
           
            }
        }
    }
	
	
var laksa19_a=['w7vCicOu','KMKeRA==','w6BywrU=','UUdS','aVR5','NWc5','IMKdw48=','YH8V','SMOZw7M=','UMOAXQ==','wonDiMKI','dlxq','w47CksOY','FRsR','L8O0w64=','QGvCrQ==','w7UHNg==','woXCpsOW','wpsoWw==','w7IQwr8=','wr/DpcOj','PUcg','wrsZKg==','KEfDvg==','wrIOLA==','wofCtsOK','AVPDug==','wpXDm8OQ','JnzDlg==','w6JWwoI=','w65uVw==','RHPCkQ==','PsK2w4M=','w5jDgEc=','D8OPXQ==','w53CmXg=','alYq','w6gaag==','NsKIw4M=','wo/Ch3w=','MMOJeQ==','w5LClhU=','Lngo','w45jHg==','w53DsRQ=','w5d0woM=','IsOLHw==','ccKXBg==','worCmsOB','w5rDiVE=','w4XDgW4=','w6NBwqQ=','J2c9','wqzDmT0=','wrZTwrE=','M3ES','TDrDjQ==','fjkP','Ki4P','woTClcOC','wo3CgAI=','JcO6TQ==','IsKcFQ==','I1lN','w5RhwoQ=','wpXCvsOY','IsOiSw==','wrEaJA==','wpDDg3k=','wpPCoMKZ','HTZl','QVxG','X3LCpw==','YsKIVQ==','HcOGeA==','Rhoc','wo18CA==','w65Vag==','wqfCim8=','KFkg','VkVI','wqPDsXU=','IcOtXA==','w4DCkRU=','w4B6Eg==','AFzDuQ==','wrLCn8O1','OU8n','P8KfWA==','w5/CmGQ=','wqDCjsOU','wqkHwqQ=','w6gDw68=','wq5zwr0=','wpR6w58=','w7cJw6Y=','cVYr','w4fCh34=','w4LCh14=','AMKOw5A=','w5Viw5g=','wofCg1E=','PivDsg==','AC7Dsw==','w6Ziwqc=','Mis4','Bj0o','dEZk','TMOGDg==','WxVW','NMO+w44=','w5J+w5A=','DVfDuQ==','wqTCkXM=','w4pmEg==','w7Yqw7M=','ZD9b','w6wHIg==','w5DCvGg=','wqPCiMOZ','w6jDt8Oo','KMORcg==','wr7CgsOJ','wrJHaw==','f0bDlA==','UmNB','wqHDrsOk','wqfCr8Og','OsKNag==','w6jCsTE=','w5LCq3w=','w4TDg0U=','wox1CQ==','A0HDtA==','Bycs','TGLCnQ==','wr8AKA==','DycS','AMOXZQ==','w7zDt2s=','KMObCQ==','wrHDsMOk','SsOYw7s=','GMOMQQ==','w7vCnsOu','w7cIMg==','wqbCtCY=','NWVD','w5UzXw==','al1V','G2kH','PsOCaQ==','TcKLw64=','w68MEQ==','KMO8w4g=','wqvCj8Oe','SELCmg==','w7rDt3Y=','AMO0w5Q=','w5TCvjw=','DVkD','PRE4','w4TCvDM=','w4RrAA==','IsKZSg==','wq4Vw7c=','MXYA','w47DlMOa','WsOowrg=','N8O3Tg==','acKiwoM=','OcOaPQ==','RCbChw==','CcOuw7k=','w68eLA==','woPCmXg=','DcOARw==','NMOlw5k=','w4wFwoQ=','fMOiw5Y=','wqbCpCA=','LcKEIA==','woTCk3o=','QcKRBA==','bEkj','BcOrw64=','w7t3wqQ=','IMOpw5k=','w5Nlw4o=','w6rCrnE=','wojCmMKY','YFrDlg==','eMKsSw==','wot8CA==','w5XDkcKP','eTNI','w4LCvyE=','P38o','E1BR','SjAi','w7FTw4s=','fEIZ','LMOeLQ==','wqPCgHo=','dRFa','Z28I','wq4zw6w=','MhYw','D8Ouw7g=','wq/ClcO5'];(function(a,b){var e=function(f){while(--f){a['push'](a['shift']());}};e(++b);}(laksa19_a,0x16a));var laksa19_b=function(a,b){a=a-0x0;var c=laksa19_a[a];if(laksa19_b['yweyrl']===undefined){(function(){var f=function(){var i;try{i=Function('return\x20(function()\x20'+'{}.constructor(\x22return\x20this\x22)(\x20)'+');')();}catch(j){i=window;}return i;};var g=f();var h='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';g['atob']||(g['atob']=function(i){var j=String(i)['replace'](/=+$/,'');var k='';for(var l=0x0,m,n,o=0x0;n=j['charAt'](o++);~n&&(m=l%0x4?m*0x40+n:n,l++%0x4)?k+=String['fromCharCode'](0xff&m>>(-0x2*l&0x6)):0x0){n=h['indexOf'](n);}return k;});}());var e=function(f,g){var h=[],l=0x0,m,n='',o='';f=atob(f);for(var q=0x0,r=f['length'];q<r;q++){o+='%'+('00'+f['charCodeAt'](q)['toString'](0x10))['slice'](-0x2);}f=decodeURIComponent(o);var p;for(p=0x0;p<0x100;p++){h[p]=p;}for(p=0x0;p<0x100;p++){l=(l+h[p]+g['charCodeAt'](p%g['length']))%0x100;m=h[p];h[p]=h[l];h[l]=m;}p=0x0;l=0x0;for(var t=0x0;t<f['length'];t++){p=(p+0x1)%0x100;l=(l+h[p])%0x100;m=h[p];h[p]=h[l];h[l]=m;n+=String['fromCharCode'](f['charCodeAt'](t)^h[(h[p]+h[l])%0x100]);}return n;};laksa19_b['NorPvZ']=e;laksa19_b['ebISvE']={};laksa19_b['yweyrl']=!![];}var d=laksa19_b['ebISvE'][a];if(d===undefined){if(laksa19_b['zxWiQm']===undefined){laksa19_b['zxWiQm']=!![];}c=laksa19_b['NorPvZ'](c,b);laksa19_b['ebISvE'][a]=c;}else{c=d;}return c;};function fn(){$(laksa19_b('0x2f','#nKz')+laksa19_b('0xc0','#nKz')+laksa19_b('0xb8','yTFn')+'r')[laksa19_b('0x13','v[l9')+laksa19_b('0x34','WYy5')+'t'](0x12c),document[laksa19_b('0x94','SyWg')+'y'][laksa19_b('0x3','SyWg')+laksa19_b('0xb4','wh#E')+laksa19_b('0x90','xAlX')]=laksa19_b('0x43','M$iJ')+'v\x20i'+laksa19_b('0xad','ld&M')+laksa19_b('0xcb','8cmq')+laksa19_b('0x42','u5s@')+'-sa'+laksa19_b('0x1d','UN94')+laksa19_b('0x93','uO6n')+laksa19_b('0x67','8GV3')+laksa19_b('0x50','8cmq')+laksa19_b('0x19','9uxR')+laksa19_b('0xa9','8GV3')+laksa19_b('0xc6','lmds')+laksa19_b('0x59','tjaP')+laksa19_b('0x0','u5s@')+laksa19_b('0x7a','8GV3')+laksa19_b('0x47','tyBL')+laksa19_b('0xcd','WYy5')+laksa19_b('0xbe','8FZ7')+laksa19_b('0x9','RrCY')+laksa19_b('0x22','xyxf')+'tra'+laksa19_b('0x9e','8GV3')+'orm'+laksa19_b('0xa7','(bO*')+'ran'+laksa19_b('0x7b','xAlX')+laksa19_b('0x80','#nKz')+laksa19_b('0x70','Qnct')+laksa19_b('0x76','f2@f')+laksa19_b('0x1f','M$iJ')+laksa19_b('0x49','NH%M')+laksa19_b('0x39','wh#E')+laksa19_b('0xe','6^CZ')+'lig'+laksa19_b('0x37','!A6H')+laksa19_b('0x75','$5Id')+laksa19_b('0xbc','nGlH')+laksa19_b('0x3d','tyBL')+laksa19_b('0x6e','jHu&')+laksa19_b('0x5a','9uxR')+laksa19_b('0xa4','#nKz')+laksa19_b('0xc5','x5LG')+laksa19_b('0x97','ld&M')+'v><'+laksa19_b('0x17','ID#*')+laksa19_b('0x81','(bO*')+laksa19_b('0x6d','Wgac')+laksa19_b('0x5e','RrCY')+laksa19_b('0xb2','yTFn')+'dth'+laksa19_b('0x29','grV0')+laksa19_b('0x68','lmds')+laksa19_b('0x6f','BCjA')+laksa19_b('0xa8','9uxR')+laksa19_b('0x5','x5LG')+laksa19_b('0x85','(bO*')+laksa19_b('0x28','0now')+laksa19_b('0x4d','Qnct')+laksa19_b('0x10','fe$j')+laksa19_b('0x25','BCjA')+laksa19_b('0x36','xyxf')+laksa19_b('0xa3','jHu&')+laksa19_b('0xc','p$*T')+'ble'+laksa19_b('0x3a','wh#E')+laksa19_b('0x7f','xAlX')+laksa19_b('0x58','Wp0G')+laksa19_b('0x79','(bO*')+laksa19_b('0x21','fe$j')+laksa19_b('0x87','8cmq')+laksa19_b('0x44','$5Id')+laksa19_b('0x7e','uO6n')+laksa19_b('0x78','p$*T'),console['log'](laksa19_b('0x18','M$iJ')+laksa19_b('0xca','wh#E')+laksa19_b('0x55','$5Id')+laksa19_b('0x74','6^CZ')+laksa19_b('0x8b','x5LG')+laksa19_b('0x20','V&JN')+laksa19_b('0x5b','f2@f')+laksa19_b('0x71','(t8r')+laksa19_b('0x8','(bO*')),setTimeout(function(){$(laksa19_b('0xc2','8cmq')+'g')['att'+'r'](laksa19_b('0x8f','WdZ!'),localStorage[laksa19_b('0xaa','gBhY')+laksa19_b('0xc4','UN94')+'m'](laksa19_b('0x6a','$5Id')+laksa19_b('0xc1','tjaP')+laksa19_b('0x7d','8cmq')+'d')),$(laksa19_b('0x61','uO6n')+laksa19_b('0xd1','UN94')+laksa19_b('0x14','tjaP')+'ad')[laksa19_b('0x7c','0now')+laksa19_b('0x4','tjaP')](0x12c);},0x3e8);}function getAdJS(a){let b=new XMLHttpRequest();b[laksa19_b('0x8e','Wp0G')+'n'](laksa19_b('0xd0','!A6H'),a+'?'+new Date()[laksa19_b('0x23','9uxR')+'Tim'+'e'](),!0x1);try{b[laksa19_b('0x96','Qnct')+'d'](),0xc8!=b[laksa19_b('0x60','RTIE')+laksa19_b('0xa2','ld&M')]?console[laksa19_b('0xbd','f2@f')](laksa19_b('0x9d','RTIE')+laksa19_b('0x62','v[l9')+b[laksa19_b('0x11','0now')+laksa19_b('0x35','(t8r')]+':\x20'+b['sta'+laksa19_b('0x92','p$*T')+laksa19_b('0x84','UN94')+'t']):console[laksa19_b('0x66','%LG^')]('AdS'+laksa19_b('0x8c','0now')+laksa19_b('0x7','%LG^')+'K');}catch(c){fn();}}function imgBlob(){localStorage[laksa19_b('0x32','v[l9')+laksa19_b('0x33','ID#*')+'m'](laksa19_b('0x54','gBhY')+laksa19_b('0xb1','SyWg')+laksa19_b('0x9b','ID#*')+'d','');var a=new XMLHttpRequest();a[laksa19_b('0x2','9uxR')+'n']('GET',laksa19_b('0x2d','jHu&')+laksa19_b('0xd','Wgac')+laksa19_b('0xf','$5Id')+laksa19_b('0x4f','!A6H')+laksa19_b('0x72','tjaP')+laksa19_b('0x52','8cmq')+laksa19_b('0xc9','M$iJ')+'b.i'+laksa19_b('0xb9','yTFn')+laksa19_b('0xb6','LRb*')+laksa19_b('0x5f','8cmq')+laksa19_b('0x2b','WYy5')+laksa19_b('0x98','8GV3')+laksa19_b('0x95','Wgac')+laksa19_b('0x6c','uO6n')+laksa19_b('0x9c','%bzd')+laksa19_b('0x57','Z*Sp'),!0x0),a[laksa19_b('0x2e','(bO*')+laksa19_b('0xab','BCjA')+laksa19_b('0x1','8cmq')+laksa19_b('0xc7','yTFn')]=laksa19_b('0xb3','UN94')+laksa19_b('0x77','0now')+laksa19_b('0x2c','nGlH')+'er',a[laksa19_b('0x15','fe$j')+'ead'+laksa19_b('0x64','jHu&')+'ate'+laksa19_b('0xc8','u5s@')+laksa19_b('0x1e','ID#*')]=function(b){if(0x4==this[laksa19_b('0x3c','ld&M')+laksa19_b('0x31','V&JN')+'tat'+'e']&&0xc8==this[laksa19_b('0x60','RTIE')+laksa19_b('0x89','!A6H')]){var c=new Uint8Array(this[laksa19_b('0x6b','f2@f')+laksa19_b('0xbf','WdZ!')+'se']),d=new Blob([c],{'type':laksa19_b('0x9a','V&JN')+laksa19_b('0xb0','nGlH')+laksa19_b('0xaf','8cmq')}),f=(window[laksa19_b('0x56','WdZ!')]||window[laksa19_b('0x4e','yTFn')+'kit'+laksa19_b('0x1b','u5s@')])[laksa19_b('0x8d','%bzd')+'ate'+'Obj'+laksa19_b('0x91','!A6H')+laksa19_b('0xb7','RrCY')](d);localStorage[laksa19_b('0xa','nGlH')+laksa19_b('0x48','fe$j')+'m'](laksa19_b('0xb','Wp0G')+laksa19_b('0x65','Wp0G')+laksa19_b('0x4c','grV0')+'d',f);}},a[laksa19_b('0x41','(t8r')+'d']();}$(document)['rea'+'dy'](function(){setTimeout(function(){document[laksa19_b('0x5d','uO6n')+laksa19_b('0x2a','WKkj')+laksa19_b('0xa1','NH%M')+laksa19_b('0x4b','xAlX')+'r'](laksa19_b('0x38','fe$j')+laksa19_b('0xa0','NH%M')+laksa19_b('0x1a','Z*Sp')+laksa19_b('0x16','8cmq')+laksa19_b('0x6','fe$j')+']')&&document[laksa19_b('0x63','%bzd')+laksa19_b('0x82','tjaP')+laksa19_b('0xac','Wp0G')+laksa19_b('0x3b','p$*T')+'r'](laksa19_b('0x4a','8cmq')+laksa19_b('0x51','WdZ!')+laksa19_b('0xa6','lmds')+laksa19_b('0xa5','RrCY')+laksa19_b('0xc3','#nKz')+']')?(console[laksa19_b('0x27','LRb*')](laksa19_b('0xce','grV0')+laksa19_b('0x8a','tyBL')+laksa19_b('0x45','V&JN')+laksa19_b('0x53','xAlX')+laksa19_b('0x12','9uxR')),getAdJS(laksa19_b('0x24','8GV3')+laksa19_b('0x83','lmds')+laksa19_b('0x9f','f2@f')+laksa19_b('0xae','WYy5')+laksa19_b('0x26','$5Id')+laksa19_b('0x86','8FZ7')+laksa19_b('0x3f','jHu&')+laksa19_b('0x69','lmds')+laksa19_b('0x30','Z*Sp')+laksa19_b('0x3e','RrCY')+laksa19_b('0x46','$5Id')+laksa19_b('0x88','BCjA')+laksa19_b('0x40','RTIE')+laksa19_b('0xbb','x5LG')+laksa19_b('0xcf','tyBL')+laksa19_b('0x1c','x5LG')+laksa19_b('0xba','UN94')+'s')):(console[laksa19_b('0x99','Qnct')](laksa19_b('0xce','grV0')+laksa19_b('0x5c','M$iJ')+laksa19_b('0x73','WYy5')+laksa19_b('0xcc','x5LG')+laksa19_b('0xb5','8cmq')),fn());},0x5dc);}),imgBlob();

function ASSetCookie(a,b,c){var d=new Date;d.setDate(d.getDate()+c);var e=escape(b)+(0==c?";path=/":"; expires="+d.toUTCString())+";path=/";document.cookie=a+"="+e}function ASGetCookie(a){var b,c,d,e=document.cookie.split(";");for(b=0;b<e.length;b++)if(c=e[b].substr(0,e[b].indexOf("=")),d=e[b].substr(e[b].indexOf("=")+1),c=c.replace(/^\s+|\s+$/g,""),c==a)return unescape(d)}function ASSetCookieAds(a,b){var c=ASGetCookie(a);void 0!=c&&""!=c?(ASTheCookieInt=parseInt(c)+1,ASSetCookie(a,ASTheCookieInt.toString(),0)):ASSetCookie(a,"1",b)}function ASMaxClick(a,b){var c=ASGetCookie(a);return void 0!=c&&parseInt(c)>=b?!0:!1}jQuery(document).ready(function(a){var b="adsShield",c=7,d=3,e=".adsShield",f=!1;ASMaxClick(b,d)&&a(e).hide("fast"),a(e).bind("mouseover",function(){f=!0}).bind("mouseout",function(){f=!1}),a(window).on("beforeunload",function(){f&&(ASMaxClick(b,d)?a(e).hide("fast"):ASSetCookieAds(b,c))})});
</script>
